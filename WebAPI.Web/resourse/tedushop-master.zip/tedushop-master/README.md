# tedushop
This is new project for training
